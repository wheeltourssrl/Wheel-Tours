# Wheel Tours – website copy

Exact static copy of https://wheeltour.netlify.app/ (built React/Vite SPA: all pages, scripts, fonts, images and SVGs).

- `404.html` = copy of `index.html`, so deep links (e.g. `/tours`, `/it/visit-us`) work on GitHub Pages.
- `_redirects` makes deep links work if deployed to Netlify.
- The site uses root-absolute paths (`/assets/...`), so it must be served from a domain root (e.g. `username.github.io`, a custom domain, or Netlify).
